"""Command-line interface for FadalWatch."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import List, Optional
from .core.db import Database
from .core.scanner import run_scan
from .core.signals import generate_signals
from .core.vuln import run_vuln_scan


def _exclude(value: Optional[str]) -> list[str]:
    return [part.strip() for part in value.split(",") if part.strip()] if value else []


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fadalwatch", description="Local network visibility toolkit")
    parser.add_argument("--data-file", help="Use a specific JSON data file")
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="Discover hosts and inspect TCP services")
    scan.add_argument("target", help="IPv4 address or subnet, e.g. 192.168.1.0/24")
    scan.add_argument("--fast", action="store_true", help="Only record discovered hosts")
    scan.add_argument("--deep", action="store_true", help="Scan ports 1-1000")
    scan.add_argument("--ports", help="Comma-separated port list")
    scan.add_argument("--top-ports", type=int, choices=[10, 20, 100])
    scan.add_argument("--threads", type=int, default=16)
    scan.add_argument("--timeout", type=float, default=1.0)
    scan.add_argument("--max-hosts", type=int, default=256)
    scan.add_argument("--exclude", help="Comma-separated IP addresses")
    scan.add_argument("--output", help="Also write this scan as JSON")
    scan.add_argument("--verbose", action="store_true")

    vuln = sub.add_parser("vuln", help="Report risky services and banner findings")
    vuln.add_argument("target")
    vuln.add_argument("--threads", type=int, default=16)
    vuln.add_argument("--timeout", type=float, default=1.0)
    vuln.add_argument("--max-hosts", type=int, default=256)
    vuln.add_argument("--exclude")
    vuln.add_argument("--verbose", action="store_true")

    audit = sub.add_parser("audit", help="Audit HTTP headers and TLS metadata for one target")
    audit.add_argument("target", help="IP address or hostname")
    audit.add_argument("--ports", default="80,443,8080,8443")
    audit.add_argument("--timeout", type=float, default=3.0)

    sub.add_parser("list", help="List the current device inventory")
    sub.add_parser("history", help="Show recent scan snapshots")
    sub.add_parser("signals", help="Detect changes between scans")
    info = sub.add_parser("info", help="Show one device")
    info.add_argument("ip")
    export = sub.add_parser("export", help="Export all stored data")
    export.add_argument("path", nargs="?", default="fadalwatch-export.json")
    serve = sub.add_parser("serve", help="Start the optional web dashboard")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=5000)
    sub.add_parser("menu", help="Open the interactive FadalWatch security console")
    sub.add_parser("shell", help="Open the independent FadalWatch command shell")
    sub.add_parser("capabilities", help="List built-in security capabilities")
    sub.add_parser("doctor", help="Check local runtime readiness")
    sub.add_parser("status", help="Show platform and inventory status")
    kernel = sub.add_parser("kernel", help="Control the FadalWatch application kernel")
    kernel_sub = kernel.add_subparsers(dest="kernel_command", required=True)
    kernel_start = kernel_sub.add_parser("start", help="Start the kernel foreground runtime")
    kernel_start.add_argument("--interval", type=int, default=10)
    kernel_sub.add_parser("status", help="Read kernel state")
    kernel_stop = kernel_sub.add_parser("stop", help="Request a cooperative kernel stop")
    kernel_stop.add_argument("--reason", default="cli_request")
    watch = sub.add_parser("watch", help="Repeat scans and record change signals")
    watch.add_argument("target")
    watch.add_argument("--interval", type=int, default=60, help="Seconds between scans")
    watch.add_argument("--cycles", type=int, default=0, help="0 means run until Ctrl-C")
    watch.add_argument("--fast", action="store_true")
    watch.add_argument("--threads", type=int, default=16)
    watch.add_argument("--timeout", type=float, default=1.0)
    watch.add_argument("--max-hosts", type=int, default=256)
    watch.add_argument("--exclude")
    watch.add_argument("--verbose", action="store_true")
    return parser


def _store(args: argparse.Namespace) -> Database:
    return Database(args.data_file) if args.data_file else Database()


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    store = _store(args)
    if args.command == "scan":
        ports = [int(item.strip()) for item in args.ports.split(",")] if args.ports else None
        run_scan(args.target, args.fast, args.deep, ports, args.top_ports, args.output,
                 args.threads, args.timeout, _exclude(args.exclude), args.verbose, store, args.max_hosts)
    elif args.command == "vuln":
        findings = run_vuln_scan(args.target, args.threads, args.timeout, _exclude(args.exclude),
                                 args.verbose, store, args.max_hosts)
        print(json.dumps(findings, indent=2, ensure_ascii=False))
    elif args.command == "audit":
        from .core.security import audit_target
        ports = [int(item.strip()) for item in args.ports.split(",") if item.strip()]
        print(json.dumps(audit_target(args.target, ports, args.timeout, store), indent=2, ensure_ascii=False))
    elif args.command == "list":
        for device in sorted(store.all_devices(), key=lambda item: item.get("ip", "")):
            ports = ", ".join(str(item["port"]) for item in device.get("open_ports", [])) or "-"
            print(f"{device['ip']:15} {device.get('os_guess', 'Unknown'):16} ports: {ports}")
    elif args.command == "history":
        print(json.dumps(store.history(limit=50), indent=2, ensure_ascii=False))
    elif args.command == "signals":
        print(json.dumps(generate_signals(database=store), indent=2, ensure_ascii=False))
    elif args.command == "info":
        device = store.get_device(args.ip)
        if not device:
            print(f"Device not found: {args.ip}", file=sys.stderr)
            return 1
        print(json.dumps(device, indent=2, ensure_ascii=False))
    elif args.command == "export":
        payload = {
            "devices": store.all_devices(),
            "history": store.history(),
            "alerts": store.all_alerts(None),
            "audits": store.all_audits(None),
        }
        Path(args.path).write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"Exported to {args.path}")
    elif args.command == "serve":
        from .web import create_app
        create_app(store).run(host=args.host, port=args.port, debug=False)
    elif args.command == "menu":
        from .menu import run_menu
        run_menu(store)
    elif args.command == "shell":
        from .shell import run_shell
        run_shell(store)
    elif args.command == "capabilities":
        from .platform import list_capabilities
        print(json.dumps(list_capabilities(), indent=2, ensure_ascii=False))
    elif args.command == "doctor":
        from .platform import doctor
        print(json.dumps(doctor(store), indent=2, ensure_ascii=False))
    elif args.command == "status":
        from .platform import status
        print(json.dumps(status(store), indent=2, ensure_ascii=False))
    elif args.command == "kernel":
        from .kernel import FadalKernel
        runtime = FadalKernel(store)
        if args.kernel_command == "start":
            runtime.run_forever(args.interval)
        elif args.kernel_command == "status":
            print(json.dumps(runtime.status(), indent=2, ensure_ascii=False))
        elif args.kernel_command == "stop":
            print(json.dumps(runtime.stop(args.reason), indent=2, ensure_ascii=False))
    elif args.command == "watch":
        if args.interval < 5:
            print("Interval must be at least 5 seconds.", file=sys.stderr)
            return 2
        cycle = 0
        try:
            while not args.cycles or cycle < args.cycles:
                cycle += 1
                print(f"\n[*] Watch cycle {cycle}{'/' + str(args.cycles) if args.cycles else ''}")
                run_scan(args.target, fast=args.fast, threads=args.threads, timeout=args.timeout,
                         exclude=_exclude(args.exclude), verbose=args.verbose, database=store,
                         max_hosts=args.max_hosts)
                signals = generate_signals(database=store)
                if signals:
                    print(json.dumps(signals, indent=2, ensure_ascii=False))
                if not args.cycles or cycle < args.cycles:
                    time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n[*] Watch stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())