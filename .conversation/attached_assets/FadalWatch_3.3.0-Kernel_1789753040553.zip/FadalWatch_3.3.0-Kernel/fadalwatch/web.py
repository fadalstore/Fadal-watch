"""Optional Flask API and a compact local dashboard."""

from __future__ import annotations

from typing import Optional

from flask import Flask, jsonify, render_template_string, request

from .core.db import Database


def create_app(database: Optional[Database] = None) -> Flask:
    app = Flask(__name__)
    store = database or Database()

    @app.get("/")
    def index():
        return render_template_string(
            """<!doctype html><title>FadalWatch</title>
            <style>body{font:16px system-ui;max-width:900px;margin:40px auto;padding:0 20px}
            table{border-collapse:collapse;width:100%}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}
            code{background:#f3f4f6;padding:2px 5px;border-radius:4px}</style>
            <h1>FadalWatch</h1><p>Local network inventory</p>
            <p><b id="count">Loading…</b> devices currently tracked.</p>
            <table><thead><tr><th>IP</th><th>OS</th><th>Vendor</th><th>Open ports</th></tr></thead>
            <tbody id="rows"></tbody></table>
            <script>fetch('/api/devices').then(r=>r.json()).then(ds=>{
              count.textContent=ds.length;
              rows.innerHTML=ds.map(d=>`<tr><td><code>${d.ip}</code></td><td>${d.os_guess||'Unknown'}</td>
              <td>${d.vendor||'Unknown'}</td><td>${(d.open_ports||[]).map(p=>p.port).join(', ')||'—'}</td></tr>`).join('')
            })</script>"""
        )

    @app.get("/api/health")
    def health():
        return jsonify({"ok": True, "version": 3, "data_file": str(store.path)})

    @app.get("/api/devices")
    def devices():
        return jsonify(store.all_devices())

    @app.get("/api/summary")
    def summary():
        current = store.all_devices()
        ports = sum(len(device.get("open_ports", [])) for device in current)
        return jsonify({
            "devices": len(current),
            "open_ports": ports,
            "history": len(store.history()),
            "alerts": len(store.all_alerts(None)),
            "audits": len(store.all_audits(None)),
        })

    @app.get("/api/device/<ip>")
    def device(ip: str):
        item = store.get_device(ip)
        return (jsonify(item), 200) if item else (jsonify({"error": "not found"}), 404)

    @app.get("/api/history")
    def history():
        limit = min(int(request.args.get("limit", 100)), 1000)
        return jsonify(store.history(limit=limit))

    @app.get("/api/alerts")
    def alerts():
        return jsonify(store.all_alerts(100))

    @app.get("/api/audits")
    def audits():
        return jsonify(store.all_audits(100))

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)