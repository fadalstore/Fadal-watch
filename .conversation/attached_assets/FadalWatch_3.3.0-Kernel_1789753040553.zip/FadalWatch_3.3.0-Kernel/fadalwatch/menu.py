"""Standalone interactive menu for FadalWatch."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from fadalwatch.core.db import Database
from fadalwatch.core.scanner import run_scan
from fadalwatch.core.security import audit_target
from fadalwatch.core.signals import generate_signals
from fadalwatch.core.vuln import run_vuln_scan


def _authorized() -> bool:
    answer = input("Waxaad leedahay ama fasax u haysataa target-kan? [y/N]: ").strip().lower()
    return answer in {"y", "yes", "haa", "h"}


def _target() -> str:
    return input("Target (IP/subnet/hostname): ").strip()


def run_menu(database: Optional[Database] = None) -> None:
    store = database or Database()
    while True:
        print(
            "\n"
            "╔══════════════════════════════════════════╗\n"
            "║       FADALWATCH SECURITY CONSOLE        ║\n"
            "╠══════════════════════════════════════════╣\n"
            "║ 1. Network scan / inventory               ║\n"
            "║ 2. Web + TLS security audit               ║\n"
            "║ 3. Defensive vulnerability report         ║\n"
            "║ 4. Current devices                        ║\n"
            "║ 5. Change signals                         ║\n"
            "║ 6. Export complete report                 ║\n"
            "║ 7. Start local dashboard                  ║\n"
            "║ 8. Kernel status                          ║\n"
            "║ 9. Start kernel                           ║\n"
            "║ 0. Exit                                   ║\n"
            "╚══════════════════════════════════════════╝"
        )
        choice = input("Dooro [0-7]: ").strip()
        try:
            if choice == "0":
                print("Nabad gelyo.")
                return
            if choice == "1":
                target = _target()
                if not _authorized():
                    print("[!] Scan waa la joojiyay.")
                    continue
                fast = input("Fast scan? [y/N]: ").strip().lower() in {"y", "yes", "h"}
                run_scan(target, fast=fast, database=store, max_hosts=256)
            elif choice == "2":
                target = _target()
                if not _authorized():
                    print("[!] Audit waa la joojiyay.")
                    continue
                result = audit_target(target, database=store)
                print(json.dumps(result, indent=2, ensure_ascii=False))
            elif choice == "3":
                target = _target()
                if not _authorized():
                    print("[!] Assessment waa la joojiyay.")
                    continue
                findings = run_vuln_scan(target, database=store, max_hosts=256)
                print(json.dumps(findings, indent=2, ensure_ascii=False))
            elif choice == "4":
                devices = store.all_devices()
                if not devices:
                    print("[!] Inventory-gu waa madhan.")
                for device in devices:
                    ports = ", ".join(str(port["port"]) for port in device.get("open_ports", [])) or "-"
                    print(f"{device.get('ip', '?'):15} {device.get('os_guess', 'Unknown'):16} ports: {ports}")
            elif choice == "5":
                print(json.dumps(generate_signals(database=store), indent=2, ensure_ascii=False))
            elif choice == "6":
                path = input("Magaca report-ka [fadalwatch-report.json]: ").strip() or "fadalwatch-report.json"
                payload = {
                    "devices": store.all_devices(),
                    "history": store.history(),
                    "alerts": store.all_alerts(None),
                    "audits": store.all_audits(None),
                }
                Path(path).write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                print(f"[+] Report saved: {path}")
            elif choice == "7":
                from fadalwatch.web import create_app
                print("[+] Dashboard: http://127.0.0.1:5000")
                create_app(store).run(host="127.0.0.1", port=5000, debug=False)
            elif choice == "8":
                from fadalwatch.kernel import FadalKernel
                print(json.dumps(FadalKernel(store).status(), indent=2, ensure_ascii=False))
            elif choice == "9":
                from fadalwatch.kernel import FadalKernel
                FadalKernel(store).run_forever(interval=10)
            else:
                print("[!] Dooro number ka mid ah 0 ilaa 9.")
        except (ValueError, OSError) as exc:
            print(f"[!] Khalad: {exc}")