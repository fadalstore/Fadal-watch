import json
import tempfile
import unittest
from pathlib import Path

from fadalwatch.core.db import Database


class DatabaseTests(unittest.TestCase):
    def test_current_inventory_and_history_are_separate(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Database(Path(folder) / "data.json")
            store.upsert_device({"ip": "192.0.2.1", "rtt": 10, "open_ports": []})
            store.upsert_device({"ip": "192.0.2.1", "rtt": 20, "open_ports": [{"port": 80}]})

            self.assertEqual(store.get_device("192.0.2.1")["rtt"], 20)
            self.assertEqual(len(store.history("192.0.2.1")), 2)
            self.assertEqual(json.loads((Path(folder) / "data.json").read_text())["version"], 3)

            store.add_audit({"target": "example.com", "score": 80, "findings": []})
            self.assertEqual(store.all_audits()[0]["target"], "example.com")


if __name__ == "__main__":
    unittest.main()