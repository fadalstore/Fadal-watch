"""Host discovery and low-impact TCP service scanning."""

from __future__ import annotations

import ipaddress
import re
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Iterable, List, Optional, Sequence

from fadalwatch.core.db import Database
from fadalwatch.utils.logger import setup_logger
from fadalwatch.utils.network import get_banner, get_vendor, guess_os

logger = setup_logger("scanner")
DEFAULT_PORTS = [21, 22, 23, 25, 53, 80, 110, 443, 445, 3306, 3389, 5900, 6379, 8080, 8443]
TOP_PORTS = {
    10: [21, 22, 23, 25, 53, 80, 110, 443, 993, 995],
    20: DEFAULT_PORTS + [143, 587, 5432, 27017],
    100: list(range(1, 101)),
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _exclude_set(exclude: Optional[Iterable[str]]) -> set[str]:
    return {str(ip).strip() for ip in (exclude or []) if str(ip).strip()}


def _validate_network(subnet: str) -> ipaddress.IPv4Network:
    network = ipaddress.ip_network(subnet, strict=False)
    if network.version != 4:
        raise ValueError("FadalWatch currently supports IPv4 targets only")
    return network


def ping_host(ip: str, timeout: float = 1.0) -> Optional[str]:
    """Return the IP when the system ping command reports success."""
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", str(max(1, int(timeout))), ip],
            capture_output=True,
            text=True,
            timeout=max(2.0, timeout + 1),
            check=False,
        )
        return ip if result.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def _nmap_discovery(subnet: str, excluded: set[str], verbose: bool) -> Optional[List[dict[str, Any]]]:
    try:
        result = subprocess.run(
            ["nmap", "-sn", "-oX", "-", subnet],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return None
        import xml.etree.ElementTree as ET

        hosts = []
        root = ET.fromstring(result.stdout)
        for host in root.findall(".//host"):
            ip_node = host.find("./address[@addrtype='ipv4']")
            if ip_node is None or ip_node.get("addr") in excluded:
                continue
            mac_node = host.find("./address[@addrtype='mac']")
            ip = ip_node.get("addr")
            hostname = None
            try:
                hostname = socket.gethostbyaddr(ip)[0]
            except (OSError, socket.herror):
                pass
            hosts.append({"ip": ip, "mac": mac_node.get("addr") if mac_node is not None else None, "hostname": hostname})
        return hosts
    except (OSError, subprocess.SubprocessError, ValueError) as exc:
        if verbose:
            logger.debug("nmap discovery unavailable: %s", exc)
        return None


def ping_sweep(subnet: str, threads: int = 16, timeout: float = 1.0, exclude: Optional[Iterable[str]] = None,
               verbose: bool = False, max_hosts: Optional[int] = None) -> List[dict[str, Any]]:
    network = _validate_network(subnet)
    excluded = _exclude_set(exclude)
    addresses = [str(ip) for ip in network.hosts() if str(ip) not in excluded]
    if max_hosts is not None and len(addresses) > max_hosts:
        raise ValueError(
            f"Target contains {len(addresses)} hosts; max_hosts is {max_hosts}. "
            "Use a smaller subnet or raise the limit deliberately."
        )
    workers = max(1, min(int(threads), 64))
    print(f"[*] Ping sweep: {len(addresses)} addresses, {workers} workers")
    hosts: List[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(ping_host, ip, timeout): ip for ip in addresses}
        for future in as_completed(futures):
            ip = future.result()
            if ip:
                hosts.append({"ip": ip, "mac": None, "hostname": None})
                if verbose:
                    print(f"    [+] {ip}")
    return sorted(hosts, key=lambda item: ipaddress.ip_address(item["ip"]))


def scan_network(subnet: str, threads: int = 16, timeout: float = 1.0,
                 exclude: Optional[Iterable[str]] = None, verbose: bool = False,
                 max_hosts: Optional[int] = None) -> List[dict[str, Any]]:
    """Discover live hosts using nmap when present, otherwise ping."""
    network = _validate_network(subnet)
    excluded = _exclude_set(exclude)
    host_count = max(0, network.num_addresses - 2)
    if max_hosts is not None and host_count > max_hosts:
        raise ValueError(
            f"Target contains {host_count} hosts; max_hosts is {max_hosts}. "
            "Use a smaller subnet or raise the limit deliberately."
        )
    discovered = _nmap_discovery(subnet, excluded, verbose)
    if discovered:
        return discovered
    return ping_sweep(subnet, threads, timeout, excluded, verbose, max_hosts)


def _probe_port(ip: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except (OSError, ValueError):
        return False


def _service_name(port: int) -> str:
    try:
        return socket.getservbyport(port, "tcp")
    except OSError:
        return "unknown"


def _ping_details(ip: str, timeout: float) -> tuple[Optional[int], Optional[float]]:
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", str(max(1, int(timeout))), ip],
            capture_output=True,
            text=True,
            timeout=max(2.0, timeout + 1),
            check=False,
        )
        line = result.stdout.lower()
        ttl_match = re.search(r"ttl[=|:](\d+)", line)
        rtt_match = re.search(r"time[=<]([0-9.]+)", line)
        return (int(ttl_match.group(1)) if ttl_match else None,
                float(rtt_match.group(1)) if rtt_match else None)
    except (OSError, subprocess.SubprocessError, ValueError):
        return None, None


def deep_scan(host_info: dict[str, Any], ports: Optional[Sequence[int]] = None,
              timeout: float = 1.0, threads: int = 32, verbose: bool = False) -> dict[str, Any]:
    ip = str(host_info["ip"])
    selected = sorted({int(port) for port in (ports or DEFAULT_PORTS) if 1 <= int(port) <= 65535})
    ttl, rtt = _ping_details(ip, timeout)
    workers = max(1, min(int(threads), 64))
    open_ports: List[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(_probe_port, ip, port, timeout): port for port in selected}
        for future in as_completed(futures):
            port = futures[future]
            if future.result():
                open_ports.append({"port": port, "service": _service_name(port)})
    open_ports.sort(key=lambda item: item["port"])
    banners = {str(item["port"]): banner for item in open_ports
               if (banner := get_banner(ip, item["port"], timeout)) is not None}
    return {
        "ip": ip,
        "ttl": ttl,
        "rtt": rtt,
        "os_guess": guess_os(ttl),
        "hostname": host_info.get("hostname"),
        "mac": host_info.get("mac"),
        "vendor": get_vendor(host_info.get("mac")),
        "open_ports": open_ports,
        "banners": banners,
        "last_seen": _now(),
    }


def run_scan(subnet: str, fast: bool = False, deep: bool = False, ports: Optional[Sequence[int]] = None,
             top_ports: Optional[int] = None, output: Optional[str] = None, threads: int = 16,
             timeout: float = 1.0, exclude: Optional[Iterable[str]] = None,
             verbose: bool = False, database: Optional[Database] = None,
             max_hosts: Optional[int] = 256) -> List[dict[str, Any]]:
    """Run a scan, persist current devices and append immutable snapshots."""
    store = database or Database()
    live_hosts = scan_network(subnet, threads, timeout, exclude, verbose, max_hosts)
    if not live_hosts:
        print("[!] No live hosts found.")
        return []
    selected_ports = list(range(1, 1001)) if deep else TOP_PORTS.get(top_ports, ports or DEFAULT_PORTS)
    results = []
    for host in live_hosts:
        if fast:
            data = {**host, "ttl": None, "rtt": None, "os_guess": "Unknown (fast)",
                    "vendor": get_vendor(host.get("mac")), "open_ports": [], "banners": {}, "last_seen": _now()}
        else:
            data = deep_scan(host, selected_ports, timeout, threads=threads, verbose=verbose)
        store.upsert_device(data, record_history=True)
        results.append(data)
    if output:
        import json
        with open(output, "w", encoding="utf-8") as handle:
            json.dump(results, handle, indent=2, ensure_ascii=False)
    print(f"[+] Saved {len(results)} device(s) to {store.path}")
    return results