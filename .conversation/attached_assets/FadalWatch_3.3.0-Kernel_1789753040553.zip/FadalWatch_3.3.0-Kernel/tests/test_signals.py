import tempfile
import unittest
from pathlib import Path

from fadalwatch.core.db import Database
from fadalwatch.core.signals import generate_signals


class SignalTests(unittest.TestCase):
    def test_new_port_and_latency_signal(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Database(Path(folder) / "data.json")
            store.upsert_device({"ip": "192.0.2.2", "os_guess": "Linux/Unix", "rtt": 5, "open_ports": []})
            store.upsert_device({"ip": "192.0.2.2", "os_guess": "Linux/Unix", "rtt": 80,
                                 "open_ports": [{"port": 443}]})
            signals = generate_signals(database=store)
            self.assertEqual({item["type"] for item in signals}, {"NEW_PORT", "LATENCY_SPIKE"})
            self.assertEqual(len(store.all_alerts()), 2)

    def test_scan_host_limit_is_enforced(self):
        from fadalwatch.core.scanner import scan_network

        with self.assertRaises(ValueError):
            scan_network("192.0.2.0/24", max_hosts=10)

    def test_platform_capabilities_and_status(self):
        from fadalwatch.platform import list_capabilities, status

        with tempfile.TemporaryDirectory() as folder:
            store = Database(Path(folder) / "data.json")
            self.assertGreaterEqual(len(list_capabilities()), 5)
            self.assertEqual(status(store)["devices"], 0)

    def test_kernel_lifecycle(self):
        from fadalwatch.kernel import FadalKernel

        with tempfile.TemporaryDirectory() as folder:
            store = Database(Path(folder) / "data.json")
            kernel = FadalKernel(store)
            self.assertEqual(kernel.status()["state"], "stopped")
            self.assertEqual(kernel.start()["state"], "running")
            self.assertEqual(kernel.heartbeat()["state"], "running")
            self.assertEqual(kernel.stop()["state"], "stopped")
            self.assertTrue(kernel.events_path.exists())


if __name__ == "__main__":
    unittest.main()