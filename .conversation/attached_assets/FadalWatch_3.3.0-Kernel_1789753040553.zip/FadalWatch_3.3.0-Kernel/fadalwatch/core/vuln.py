"""Passive, banner-based findings and risky-service checks.

This module reports exposure; it does not exploit services, authenticate, or
guess credentials.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional

from fadalwatch.core.db import Database
from fadalwatch.core.scanner import DEFAULT_PORTS, deep_scan, scan_network

VULN_DB = {
    "vsftpd": ("CRITICAL", "Possible vsftpd 2.3.4 backdoor (CVE-2011-2523)"),
    "openssh": ("HIGH", "Old OpenSSH version may expose known issues"),
    "apache": ("HIGH", "Old Apache version may expose known issues"),
    "nginx": ("HIGH", "Old nginx version may expose known issues"),
}

DANGEROUS_PORTS = {
    21: ("HIGH", "FTP may expose credentials in plaintext"),
    23: ("HIGH", "Telnet is unencrypted"),
    445: ("HIGH", "SMB should be restricted and patched"),
    3389: ("MEDIUM", "RDP should be restricted and patched"),
    3306: ("MEDIUM", "MySQL should not be publicly reachable"),
}


def check_vulnerability(ip: str, open_ports: Iterable[dict[str, Any]],
                        banners: Optional[dict[str, str]] = None) -> list[dict[str, Any]]:
    findings = []
    seen = set()
    for item in open_ports:
        port = int(item.get("port", 0))
        if port in DANGEROUS_PORTS:
            severity, message = DANGEROUS_PORTS[port]
            key = (port, message)
            if key not in seen:
                findings.append({"ip": ip, "port": port, "severity": severity, "msg": message})
                seen.add(key)
    for port_text, banner in (banners or {}).items():
        lower = banner.lower()
        for product, (severity, message) in VULN_DB.items():
            if product in lower:
                findings.append({"ip": ip, "port": int(port_text), "severity": severity, "msg": message,
                                 "evidence": banner[:160]})
    return findings


def run_vuln_scan(subnet: str, threads: int = 16, timeout: float = 1,
                  exclude: Optional[Iterable[str]] = None, verbose: bool = False,
                  database: Optional[Database] = None, max_hosts: Optional[int] = 256) -> list[dict[str, Any]]:
    store = database or Database()
    findings = []
    for host in scan_network(subnet, threads, timeout, exclude, verbose, max_hosts):
        device = deep_scan(host, DEFAULT_PORTS, timeout, threads=threads, verbose=verbose)
        findings.extend(check_vulnerability(device["ip"], device["open_ports"], device["banners"]))
    for finding in findings:
        store.add_alert({**finding, "type": "VULNERABILITY"})
    return findings