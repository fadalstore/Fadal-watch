from __future__ import annotations

import logging
import os
from pathlib import Path


def setup_logger(name: str = "fadalwatch") -> logging.Logger:
    """Return an idempotent logger that respects FADALWATCH_DATA_DIR."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    if logger.handlers:
        return logger

    log_dir = Path(os.environ.get("FADALWATCH_DATA_DIR", Path.home() / ".local/share/fadalwatch"))
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(log_dir / f"{name}.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    return logger