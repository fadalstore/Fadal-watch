# FadalWatch Safe Edition

FadalWatch waa qalab Python ah oo loogu talagalay **network visibility** gudaha
shabakad aad maamusho: wuxuu helaa hosts nool, wuxuu eegaa TCP ports la doortay,
wuxuuna kaydiyaa history si isbeddellada loo arko. Version-kan wuxuu diiradda
saarayaa network monitoring iyo defensive assessment oo keliya.

> Isticmaal oo keliya subnet-yada iyo IP-yada aad leedahay ama aad haysato
> oggolaansho cad oo aad ku baarayso. FadalWatch ma sameeyo exploit, password
> guessing, ama authentication.

## Rakibid

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
```

Xogta waxaa lagu kaydiyaa `~/.local/share/fadalwatch/fadalwatch.json`.
Meeshaas waxaad ku beddeli kartaa:

```bash
export FADALWATCH_DATA_DIR=/path/to/fadalwatch-data
```

## Tusaalooyin

```bash
# Scan degdeg ah
fadalwatch scan 192.168.1.0/24 --fast

# Scan ports-ka muhiimka ah
fadalwatch scan 192.168.1.0/24 --top-ports 20 --threads 32

# Fur hal security audit ah oo HTTP/TLS ah
fadalwatch audit example.com --ports 80,443,8443

# Ka saar router-ka ama IP kale
fadalwatch scan 192.168.1.0/24 --exclude 192.168.1.1

# Arag inventory, history, iyo isbeddello
fadalwatch list
fadalwatch history
fadalwatch signals

# Kormeer joogto ah; Ctrl-C ku jooji
fadalwatch watch 192.168.1.0/24 --interval 60 --max-hosts 256

# Bilow dashboard-ka maxalliga ah
fadalwatch serve

# Fur menu-ga gudaha tool-ka
fadalwatch menu

# Shell u gaar ah oo aan ku xirnayn menu ama scripts kale
fadalwatch shell

# Platform status iyo readiness check
fadalwatch capabilities
fadalwatch doctor
fadalwatch status

# Bilaw kernel-ka gudaha FadalWatch
fadalwatch kernel start --interval 10

# Ka eeg ama jooji kernel-ka
fadalwatch kernel status
fadalwatch kernel stop
```

Dashboard-ku wuxuu ka furmayaa `http://127.0.0.1:5000`, API-guna wuxuu leeyahay
`/api/devices`, `/api/summary`, `/api/history`, `/api/alerts`, `/api/audits`,
iyo `/api/health`.

## Fikradda platform-ka

FadalWatch ma isku dayayo inuu noqdo Debian ama Kali Linux oo dhan. Labadaas
waa operating systems/distributions. FadalWatch wuxuu leeyahay security console
u gaar ah oo ku shaqeeya Linux, Windows, ama macOS, wuxuuna isku keenaa
capabilities-kiisa, health checks, data store, reports, menu, iyo shell hal
tool gudaheeda.

`fadalwatch kernel` waa application kernel/control-plane gudaha tool-ka. Ma aha
Linux kernel cusub; wuxuu maamulaa runtime state, heartbeat, events, iyo
cooperative stop si modules-ka security-ga ay ugu shaqeeyaan hal nidaam.

## Waxa aan release-kan ku jirin

Archive-kii hore wuxuu lahaa plugins soo saaraya ama tijaabinaya private keys,
seed phrases, brainwallets, wallet files, iyo key material ku jiray `exports/`.
Qaybahaas laguma darin Safe Edition, mana aha in xogtaas lagu commit-gareeyo
Git ama lagu share-gareeyo archive kale. Haddii key material-ka ku jira
archive-ga hore uu dhab yahay, u qaado inuu shaaca baxay oo u wareeji assets-ka
wallet cusub oo ammaan ah.