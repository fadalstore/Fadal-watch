"""A dependency-light command shell for operating FadalWatch independently."""

from __future__ import annotations

import cmd
import json
import shlex
from pathlib import Path
from typing import Optional

from fadalwatch.core.db import Database
from fadalwatch.core.scanner import run_scan
from fadalwatch.core.security import audit_target
from fadalwatch.core.signals import generate_signals
from fadalwatch.core.vuln import run_vuln_scan
from fadalwatch.platform import doctor, list_capabilities, status


class FadalShell(cmd.Cmd):
    prompt = "fadalwatch> "

    def __init__(self, database: Optional[Database] = None):
        super().__init__()
        self.store = database or Database()
        self.intro = (
            "FadalWatch Security Shell\n"
            "Type 'help' for commands. All scans must target systems you own or are authorized to assess."
        )

    @staticmethod
    def _args(line: str) -> list[str]:
        return shlex.split(line)

    def _authorized(self) -> bool:
        answer = input("Authorized target? [y/N]: ").strip().lower()
        return answer in {"y", "yes", "h", "haa"}

    def do_capabilities(self, _line: str) -> None:
        """List the capabilities built into this FadalWatch runtime."""
        print(json.dumps(list_capabilities(), indent=2, ensure_ascii=False))

    def do_status(self, _line: str) -> None:
        """Show current inventory and platform status."""
        print(json.dumps(status(self.store), indent=2, ensure_ascii=False))

    def do_doctor(self, _line: str) -> None:
        """Check optional dependencies and local readiness."""
        print(json.dumps(doctor(self.store), indent=2, ensure_ascii=False))

    def do_scan(self, line: str) -> None:
        """scan TARGET [--fast]"""
        args = self._args(line)
        if not args or not self._authorized():
            print("Usage: scan TARGET [--fast]")
            return
        run_scan(args[0], fast="--fast" in args, database=self.store, max_hosts=256)

    def do_audit(self, line: str) -> None:
        """audit TARGET [PORT ...]"""
        args = self._args(line)
        if not args or not self._authorized():
            print("Usage: audit TARGET [PORT ...]")
            return
        ports = [int(port) for port in args[1:]] or [80, 443, 8080, 8443]
        print(json.dumps(audit_target(args[0], ports, database=self.store), indent=2, ensure_ascii=False))

    def do_vuln(self, line: str) -> None:
        """vuln TARGET"""
        args = self._args(line)
        if len(args) != 1 or not self._authorized():
            print("Usage: vuln TARGET")
            return
        print(json.dumps(run_vuln_scan(args[0], database=self.store, max_hosts=256),
                          indent=2, ensure_ascii=False))

    def do_devices(self, _line: str) -> None:
        """List the current device inventory."""
        for device in self.store.all_devices():
            ports = ", ".join(str(item["port"]) for item in device.get("open_ports", [])) or "-"
            print(f"{device.get('ip', '?'):15} {device.get('os_guess', 'Unknown'):16} ports: {ports}")

    def do_signals(self, _line: str) -> None:
        """Calculate changes between recent snapshots."""
        print(json.dumps(generate_signals(database=self.store), indent=2, ensure_ascii=False))

    def do_export(self, line: str) -> None:
        """export [PATH]"""
        path = self._args(line)
        filename = path[0] if path else "fadalwatch-report.json"
        payload = {
            "devices": self.store.all_devices(),
            "history": self.store.history(),
            "alerts": self.store.all_alerts(None),
            "audits": self.store.all_audits(None),
        }
        Path(filename).write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"Exported to {filename}")

    def do_dashboard(self, _line: str) -> None:
        """Start the local dashboard on 127.0.0.1:5000."""
        from fadalwatch.web import create_app
        create_app(self.store).run(host="127.0.0.1", port=5000, debug=False)

    def do_exit(self, _line: str) -> bool:
        """Exit the security shell."""
        return True

    do_quit = do_exit
    do_EOF = do_exit


def run_shell(database: Optional[Database] = None) -> None:
    FadalShell(database).cmdloop()