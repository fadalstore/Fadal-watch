"""Conservative network probes used by the scanner."""

from __future__ import annotations

import re
import socket
from typing import Optional


MAC_VENDORS = {
    "000393": "Apple",
    "000800": "Cisco",
    "000C29": "VMware",
    "005056": "VMware",
    "00155D": "Microsoft",
    "001C42": "Parallels",
    "001E4F": "TP-Link",
    "002655": "Intel",
    "003067": "Belkin",
    "64200C": "Samsung",
    "AC293A": "Apple",
    "B827EB": "Raspberry Pi",
    "DCA632": "Apple",
    "F4F5D8": "Samsung",
}

TTL_OS = {32: "Android", 60: "AIX", 64: "Linux/Unix", 128: "Windows", 254: "BSD", 255: "Cisco/HP"}


def get_vendor(mac: Optional[str]) -> str:
    if not mac:
        return "Unknown"
    prefix = re.sub(r"[^0-9A-Fa-f]", "", mac).upper()[:6]
    return MAC_VENDORS.get(prefix, "Unknown")


def guess_os(ttl: Optional[int]) -> str:
    return TTL_OS.get(ttl, f"Unknown (TTL={ttl})" if ttl else "Unknown")


def get_banner(ip: str, port: int, timeout: float = 1.5) -> Optional[str]:
    """Read a short service greeting; never sends credentials or commands."""
    try:
        with socket.create_connection((ip, port), timeout=timeout) as sock:
            sock.settimeout(timeout)
            if port in {80, 8080, 8000, 8443}:
                sock.sendall(b"HEAD / HTTP/1.0\r\nHost: target\r\nConnection: close\r\n\r\n")
            else:
                sock.sendall(b"\n")
            return sock.recv(1024).decode("utf-8", errors="ignore").strip() or None
    except (OSError, ValueError):
        return None