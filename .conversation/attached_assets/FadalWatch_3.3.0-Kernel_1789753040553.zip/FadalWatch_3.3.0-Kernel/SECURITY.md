# Security notes

FadalWatch Safe Edition is for assets and networks that you own or are
explicitly authorized to assess.

## Scope

The supported features are host discovery, low-impact TCP service probing,
banner collection, local history, change signals, and defensive exposure
reporting. It also performs read-only HTTP header and TLS certificate metadata
audits. The tool does not authenticate to services, guess passwords, exploit
vulnerabilities, or recover cryptocurrency private keys.

## Do not ship secrets

Do not commit wallet files, seed phrases, private keys, API tokens, or scan
exports containing sensitive data. The full archive supplied with the project
contained key-like material under `exports/`; the Safe Edition intentionally
excludes those files and the key-recovery plugins.

If any real private key or seed phrase was included in the old archive, treat it
as compromised, rotate it, and remove it from backups and shared storage.