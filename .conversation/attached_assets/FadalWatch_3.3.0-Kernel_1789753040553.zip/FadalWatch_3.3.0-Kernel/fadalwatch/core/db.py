"""Small atomic JSON datastore used by FadalWatch.

The old version used a machine-specific TinyDB path and overwrote the only
copy of a device on every scan.  This store keeps a current device inventory
and immutable scan snapshots in one portable file.
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Union


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_data_dir() -> Path:
    configured = os.environ.get("FADALWATCH_DATA_DIR")
    if configured:
        return Path(configured).expanduser()
    return Path.home() / ".local" / "share" / "fadalwatch"


class Database:
    """Portable local store with a backwards-compatible device API."""

    def __init__(self, path: Optional[Union[os.PathLike, str]] = None):
        self.path = Path(path).expanduser() if path else default_data_dir() / "fadalwatch.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._data = self._load()

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"version": 3, "devices": {}, "history": [], "alerts": [], "audits": []}
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict) and "devices" in data:
                data.setdefault("version", 3)
                data.setdefault("history", [])
                data.setdefault("alerts", [])
                data.setdefault("audits", [])
                return data
        except (OSError, json.JSONDecodeError):
            # A corrupt file must not make the CLI unusable.  Preserve it for
            # manual recovery and start with an empty store.
            backup = self.path.with_suffix(".corrupt.json")
            try:
                self.path.replace(backup)
            except OSError:
                pass
        return {"version": 3, "devices": {}, "history": [], "alerts": [], "audits": []}

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=".fadalwatch-", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(self._data, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    @staticmethod
    def _copy(value: Any) -> Any:
        return json.loads(json.dumps(value))

    def upsert_device(self, data: Dict[str, Any], record_history: bool = True) -> Dict[str, Any]:
        if not data.get("ip"):
            raise ValueError("Device data must include an IP address")
        device = self._copy(data)
        device.setdefault("last_seen", utc_now())
        with self._lock:
            self._data["devices"][device["ip"]] = device
            if record_history:
                self._data["history"].append(self._copy(device))
            self._save()
        return self._copy(device)

    def get_device(self, ip: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            device = self._data["devices"].get(ip)
            return self._copy(device) if device else None

    def all_devices(self) -> List[Dict[str, Any]]:
        with self._lock:
            return self._copy(list(self._data["devices"].values()))

    def all(self) -> List[Dict[str, Any]]:
        """Compatibility alias for the previous TinyDB-backed API."""
        return self.all_devices()

    def history(self, ip: Optional[str] = None, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        with self._lock:
            rows: Iterable[Dict[str, Any]] = self._data["history"]
            if ip:
                rows = (row for row in rows if row.get("ip") == ip)
            result = self._copy(list(rows))
        result.sort(key=lambda row: row.get("last_seen", ""), reverse=True)
        return result[:limit] if limit else result

    def search_by_time(self, timestamp: str) -> List[Dict[str, Any]]:
        return [row for row in self.history() if row.get("last_seen") == timestamp]

    def add_alert(self, alert: Dict[str, Any]) -> Dict[str, Any]:
        item = self._copy(alert)
        item.setdefault("timestamp", utc_now())
        with self._lock:
            self._data["alerts"].append(item)
            self._save()
        return self._copy(item)

    def all_alerts(self, limit: Optional[int] = 100) -> List[Dict[str, Any]]:
        with self._lock:
            alerts = self._copy(self._data["alerts"])
        alerts.sort(key=lambda item: item.get("timestamp", ""), reverse=True)
        return alerts[:limit] if limit else alerts

    def add_audit(self, audit: Dict[str, Any]) -> Dict[str, Any]:
        item = self._copy(audit)
        item.setdefault("timestamp", utc_now())
        with self._lock:
            self._data["audits"].append(item)
            self._save()
        return self._copy(item)

    def all_audits(self, limit: Optional[int] = 100) -> List[Dict[str, Any]]:
        with self._lock:
            audits = self._copy(self._data["audits"])
        audits.sort(key=lambda item: item.get("timestamp", ""), reverse=True)
        return audits[:limit] if limit else audits

    def clear(self) -> None:
        with self._lock:
            self._data = {"version": 3, "devices": {}, "history": [], "alerts": [], "audits": []}
            self._save()