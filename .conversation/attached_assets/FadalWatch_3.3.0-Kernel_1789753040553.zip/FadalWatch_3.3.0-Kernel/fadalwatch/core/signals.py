"""Change detection over immutable scan snapshots."""

from __future__ import annotations

from typing import Any, Optional

from fadalwatch.core.db import Database


def generate_signals(latency_threshold: float = 50, database: Optional[Database] = None) -> list[dict[str, Any]]:
    store = database or Database()
    by_ip: dict[str, list[dict[str, Any]]] = {}
    for row in store.history():
        by_ip.setdefault(row.get("ip", ""), []).append(row)

    signals: list[dict[str, Any]] = []
    for ip, snapshots in by_ip.items():
        snapshots.sort(key=lambda row: row.get("last_seen", ""))
        if len(snapshots) < 2:
            continue
        previous, current = snapshots[-2], snapshots[-1]
        if previous.get("os_guess") != current.get("os_guess") and "Unknown" not in {
            previous.get("os_guess"), current.get("os_guess")
        }:
            signals.append({"level": "WARN", "type": "OS_CHANGE", "ip": ip,
                            "msg": f"OS changed: {previous.get('os_guess')} -> {current.get('os_guess')}"})
        old_ports = {item.get("port") for item in previous.get("open_ports", [])}
        new_ports = {item.get("port") for item in current.get("open_ports", [])} - old_ports
        if new_ports:
            signals.append({"level": "WARN", "type": "NEW_PORT", "ip": ip,
                            "msg": f"New open port(s): {sorted(new_ports)}"})
        old_rtt, new_rtt = previous.get("rtt"), current.get("rtt")
        if old_rtt is not None and new_rtt is not None and new_rtt - old_rtt > latency_threshold:
            signals.append({"level": "INFO", "type": "LATENCY_SPIKE", "ip": ip,
                            "msg": f"Latency increased by {new_rtt - old_rtt:.2f}ms"})

    for signal in signals:
        store.add_alert(signal)
    return signals