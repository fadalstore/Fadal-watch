from setuptools import find_packages, setup

setup(
    name="fadalwatch",
    version="3.3.0",
    packages=find_packages(),
    entry_points={"console_scripts": ["fadalwatch=fadalwatch.cli:main"]},
    install_requires=["flask>=2.0"],
    description="Local network visibility, history, and low-impact service assessment",
    python_requires=">=3.9",
)