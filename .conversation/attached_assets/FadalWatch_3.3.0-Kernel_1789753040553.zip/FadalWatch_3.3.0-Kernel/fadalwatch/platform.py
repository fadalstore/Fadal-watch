"""FadalWatch platform layer: capabilities, health checks, and runtime status."""

from __future__ import annotations

import importlib.util
import os
import platform as host_platform
import shutil
import sys
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from fadalwatch import __version__
from fadalwatch.core.db import Database


@dataclass(frozen=True)
class Capability:
    name: str
    category: str
    description: str
    safety: str = "read-only"


CAPABILITIES = (
    Capability("network-discovery", "network", "Find live hosts with nmap or ping fallback"),
    Capability("service-inspection", "network", "Inspect selected TCP services and short banners"),
    Capability("http-security-audit", "web", "Check HTTP security headers and status"),
    Capability("tls-audit", "web", "Inspect TLS protocol, certificate, and cipher metadata"),
    Capability("exposure-report", "defense", "Report risky services without exploitation"),
    Capability("change-signals", "defense", "Detect new ports, OS changes, and latency spikes"),
    Capability("continuous-watch", "operations", "Repeat bounded scans and store alerts"),
    Capability("local-dashboard", "operations", "Serve a local dashboard and JSON API"),
    Capability("json-reporting", "operations", "Export devices, audits, history, and alerts"),
)


def list_capabilities() -> List[Dict[str, str]]:
    return [asdict(capability) for capability in CAPABILITIES]


def _command_check(name: str) -> Dict[str, Any]:
    path = shutil.which(name)
    return {"name": name, "available": bool(path), "path": path}


def doctor(database: Optional[Database] = None) -> Dict[str, Any]:
    """Return a machine-readable readiness report without changing the system."""
    store = database or Database()
    checks: List[Dict[str, Any]] = [
        {"name": "python", "available": True, "version": sys.version.split()[0]},
        {"name": "data_directory", "available": store.path.parent.exists(), "path": str(store.path.parent)},
        _command_check("ping"),
        _command_check("nmap"),
        {
            "name": "flask",
            "available": importlib.util.find_spec("flask") is not None,
            "optional": True,
        },
    ]
    return {
        "tool": "FadalWatch",
        "version": __version__,
        "host": host_platform.platform(),
        "python": sys.version.split()[0],
        "data_file": str(store.path),
        "device_count": len(store.all_devices()),
        "audit_count": len(store.all_audits(None)),
        "alert_count": len(store.all_alerts(None)),
        "checks": checks,
    }


def status(database: Optional[Database] = None) -> Dict[str, Any]:
    store = database or Database()
    return {
        "tool": "FadalWatch",
        "version": __version__,
        "host": host_platform.node() or "local",
        "os": host_platform.system(),
        "data_file": str(store.path),
        "devices": len(store.all_devices()),
        "history": len(store.history()),
        "audits": len(store.all_audits(None)),
        "alerts": len(store.all_alerts(None)),
        "capabilities": len(CAPABILITIES),
    }