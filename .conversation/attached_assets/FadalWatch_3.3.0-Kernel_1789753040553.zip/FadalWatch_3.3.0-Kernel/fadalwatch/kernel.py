"""FadalWatch application kernel and lightweight runtime supervisor.

This is an application kernel, not a replacement for the Linux kernel. It
owns runtime state, heartbeat events, and a cooperative stop mechanism so
security jobs can share one predictable control plane.
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from fadalwatch.core.db import Database


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class FadalKernel:
    def __init__(self, database: Optional[Database] = None):
        self.database = database or Database()
        self.state_path = self.database.path.with_name("kernel-state.json")
        self.events_path = self.database.path.with_name("kernel-events.jsonl")

    def _read_state(self) -> Dict[str, Any]:
        if not self.state_path.exists():
            return {"state": "stopped", "pid": None, "started_at": None, "heartbeat": None}
        try:
            return json.loads(self.state_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"state": "stopped", "pid": None, "started_at": None, "heartbeat": None}

    def _write_state(self, state: Dict[str, Any]) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, self.state_path)

    def emit(self, event: str, **payload: Any) -> Dict[str, Any]:
        item = {"timestamp": _now(), "event": event, **payload}
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        with self.events_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        return item

    def status(self) -> Dict[str, Any]:
        state = self._read_state()
        state.update({
            "state_file": str(self.state_path),
            "events_file": str(self.events_path),
            "data_file": str(self.database.path),
        })
        return state

    def start(self) -> Dict[str, Any]:
        current = self._read_state()
        if current.get("state") == "running":
            return current
        state = {
            "state": "running",
            "pid": os.getpid(),
            "started_at": _now(),
            "heartbeat": _now(),
        }
        self._write_state(state)
        self.emit("kernel_started", pid=os.getpid())
        return state

    def heartbeat(self) -> Dict[str, Any]:
        state = self._read_state()
        if state.get("state") != "running":
            return state
        state["heartbeat"] = _now()
        state["pid"] = os.getpid()
        self._write_state(state)
        self.emit("heartbeat", pid=os.getpid())
        return state

    def stop(self, reason: str = "requested") -> Dict[str, Any]:
        state = self._read_state()
        state.update({"state": "stopped", "stopped_at": _now(), "stop_reason": reason})
        self._write_state(state)
        self.emit("kernel_stopped", reason=reason)
        return state

    def run_forever(self, interval: int = 10) -> None:
        if interval < 2:
            raise ValueError("Kernel interval must be at least 2 seconds")
        self.start()
        print(f"[+] FadalWatch kernel started; heartbeat every {interval}s")
        print("[*] Stop with Ctrl-C or run: fadalwatch kernel stop")
        try:
            while self._read_state().get("state") == "running":
                self.heartbeat()
                time.sleep(interval)
        except KeyboardInterrupt:
            self.stop("keyboard_interrupt")
        finally:
            if self._read_state().get("state") == "running":
                self.stop("runtime_exit")