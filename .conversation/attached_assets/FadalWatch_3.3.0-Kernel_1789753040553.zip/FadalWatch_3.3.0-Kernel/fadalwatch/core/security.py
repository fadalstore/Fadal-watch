"""Non-destructive security audits for web services and TLS endpoints."""

from __future__ import annotations

import http.client
import ipaddress
import socket
import ssl
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional

from fadalwatch.core.db import Database, utc_now


def _severity_score(findings: Iterable[Dict[str, Any]]) -> int:
    deductions = {"CRITICAL": 35, "HIGH": 20, "MEDIUM": 10, "LOW": 4, "INFO": 0}
    return max(0, 100 - sum(deductions.get(item.get("severity", "INFO"), 0) for item in findings))


def _finding(severity: str, code: str, message: str, evidence: Any = None) -> Dict[str, Any]:
    item = {"severity": severity, "code": code, "message": message}
    if evidence is not None:
        item["evidence"] = evidence
    return item


def audit_http(target: str, port: int = 80, timeout: float = 3.0) -> Dict[str, Any]:
    """Inspect headers and status only; it never submits a form or follows links."""
    secure = port in {443, 8443}
    findings = []
    headers: Dict[str, str] = {}
    connection = None
    try:
        if secure:
            connection = http.client.HTTPSConnection(
                target, port, timeout=timeout, context=ssl._create_unverified_context()
            )
        else:
            connection = http.client.HTTPConnection(target, port, timeout=timeout)
        connection.request("HEAD", "/", headers={"User-Agent": "FadalWatch-Security-Audit/3.1"})
        response = connection.getresponse()
        headers = {key.lower(): value.strip() for key, value in response.getheaders()}
        if response.status >= 500:
            findings.append(_finding("MEDIUM", "HTTP_5XX", f"HTTP returned status {response.status}"))
        elif response.status >= 400:
            findings.append(_finding("LOW", "HTTP_4XX", f"HTTP returned status {response.status}"))
    except (OSError, http.client.HTTPException, ValueError) as exc:
        return {
            "target": target,
            "port": port,
            "protocol": "https" if secure else "http",
            "reachable": False,
            "error": str(exc),
            "findings": [_finding("INFO", "UNREACHABLE", "HTTP endpoint could not be read")],
            "score": 0,
        }
    finally:
        if connection:
            connection.close()

    required = {
        "x-content-type-options": ("MEDIUM", "MISSING_NOSNIFF", "X-Content-Type-Options is missing"),
        "x-frame-options": ("MEDIUM", "MISSING_FRAME_PROTECTION", "X-Frame-Options is missing"),
        "content-security-policy": ("MEDIUM", "MISSING_CSP", "Content-Security-Policy is missing"),
        "referrer-policy": ("LOW", "MISSING_REFERRER_POLICY", "Referrer-Policy is missing"),
    }
    for header, (severity, code, message) in required.items():
        if header not in headers:
            findings.append(_finding(severity, code, message))
    if secure and "strict-transport-security" not in headers:
        findings.append(_finding("MEDIUM", "MISSING_HSTS", "HTTPS endpoint does not advertise HSTS"))
    if "server" in headers:
        findings.append(_finding("INFO", "SERVER_DISCLOSURE", "Server header is exposed", headers["server"]))
    return {
        "target": target,
        "port": port,
        "protocol": "https" if secure else "http",
        "reachable": True,
        "status": response.status,
        "headers": headers,
        "findings": findings,
        "score": _severity_score(findings),
    }


def audit_tls(target: str, port: int = 443, timeout: float = 5.0) -> Dict[str, Any]:
    """Read certificate metadata and negotiated parameters without credentials."""
    findings = []
    certificate: Dict[str, Any] = {}
    verified = True
    sock = None
    try:
        context = ssl.create_default_context()
        try:
            sock = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=target)
            sock.settimeout(timeout)
            sock.connect((target, port))
        except (ssl.SSLCertVerificationError, ssl.SSLError):
            verified = False
            if sock:
                sock.close()
            context = ssl._create_unverified_context()
            sock = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=target)
            sock.settimeout(timeout)
            sock.connect((target, port))
        certificate = sock.getpeercert() or {}
        cipher = sock.cipher()
        protocol = sock.version()
        if not verified:
            findings.append(_finding("HIGH", "CERT_NOT_VERIFIED", "Certificate validation failed"))
        if protocol in {"TLSv1", "TLSv1.1", "SSLv3"}:
            findings.append(_finding("HIGH", "OLD_TLS", f"Obsolete protocol negotiated: {protocol}"))
        if cipher and any(token in cipher[0].upper() for token in ("RC4", "3DES", "NULL", "EXPORT")):
            findings.append(_finding("HIGH", "WEAK_CIPHER", f"Weak cipher negotiated: {cipher[0]}"))
        expires = certificate.get("notAfter")
        if expires:
            expiry = datetime.strptime(expires, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            days = (expiry - datetime.now(timezone.utc)).days
            if days < 0:
                findings.append(_finding("HIGH", "CERT_EXPIRED", "Certificate is expired"))
            elif days < 30:
                findings.append(_finding("MEDIUM", "CERT_EXPIRING", f"Certificate expires in {days} days"))
            certificate["days_remaining"] = days
        return {
            "target": target,
            "port": port,
            "reachable": True,
            "verified": verified,
            "protocol": protocol,
            "cipher": cipher[0] if cipher else None,
            "certificate": certificate,
            "findings": findings,
            "score": _severity_score(findings),
        }
    except (OSError, ssl.SSLError, ValueError) as exc:
        return {
            "target": target,
            "port": port,
            "reachable": False,
            "error": str(exc),
            "findings": [_finding("INFO", "TLS_UNREACHABLE", "TLS endpoint could not be inspected")],
            "score": 0,
        }
    finally:
        if sock:
            sock.close()


def audit_target(target: str, ports: Optional[Iterable[int]] = None,
                 timeout: float = 3.0, database: Optional[Database] = None) -> Dict[str, Any]:
    """Run focused web/TLS checks against one explicitly supplied target."""
    try:
        ipaddress.ip_address(target)
    except ValueError:
        # Hostnames are allowed for TLS certificate/SNI audits.
        if not target or any(char in target for char in "/\\ "):
            raise ValueError("Target must be an IP address or hostname")
    selected = sorted({int(port) for port in (ports or [80, 443, 8080, 8443]) if 1 <= int(port) <= 65535})
    checks = []
    for port in selected:
        if port in {443, 8443}:
            checks.append(audit_tls(target, port, timeout))
        if port in {80, 443, 8080, 8443}:
            checks.append(audit_http(target, port, timeout))
    findings = [finding for check in checks for finding in check.get("findings", [])]
    result = {
        "target": target,
        "ports": selected,
        "timestamp": utc_now(),
        "checks": checks,
        "findings": findings,
        "score": _severity_score(findings),
    }
    if database:
        database.add_audit(result)
        for finding in findings:
            database.add_alert({"type": "SECURITY_AUDIT", "target": target, **finding})
    return result