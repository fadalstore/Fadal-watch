"""FadalWatch: a small, local-first network visibility toolkit."""

__version__ = "3.3.0"

from .core.db import Database
from .core.scanner import deep_scan, run_scan, scan_network
from .core.signals import generate_signals
from .core.vuln import check_vulnerability, run_vuln_scan
from .core.security import audit_http, audit_target, audit_tls

__all__ = [
    "Database",
    "check_vulnerability",
    "audit_http",
    "audit_target",
    "audit_tls",
    "deep_scan",
    "generate_signals",
    "run_scan",
    "run_vuln_scan",
    "scan_network",
]